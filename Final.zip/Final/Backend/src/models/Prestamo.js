export class Prestamo{
    id;
    estado;
    FechaSolicitud;
    FechaAceptado;
    FechaEntregado;
    FechaDevuelto;
    Fk_Objeto;
    Fk_Usuario;
    Fk_Admin;
}