export class Objeto {
    id;
    nombre;
    estado;
    enPrestamo;
    fk_Categoria;
    Activo
}