export class Categoria{
    id;
    nombre;
}